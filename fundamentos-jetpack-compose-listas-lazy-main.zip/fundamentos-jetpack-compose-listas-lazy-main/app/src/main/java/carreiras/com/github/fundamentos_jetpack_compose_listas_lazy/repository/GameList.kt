package carreiras.com.github.fundamentos_jetpack_compose_listas_lazy.repository

import carreiras.com.github.fundamentos_jetpack_compose_listas_lazy.model.Car

fun getAllCars(): List<Car> {
    return listOf(
        Car(id = 1, model = "Fusca", manufacturer = "Volkswagen", year = 1970),
        Car(id = 2, model = "Maverick", manufacturer = "Ford", year = 1973),
        Car(id = 3, model = "Opala", manufacturer = "Chevrolet", year = 1980),
        Car(id = 4, model = "Karmann-Ghia", manufacturer = "Volkswagen", year = 1968),
        Car(id = 5, model = "Mustang", manufacturer = "Ford", year = 1967),
        Car(id = 6, model = "Camaro", manufacturer = "Chevrolet", year = 1969),
        Car(id = 7, model = "Passat", manufacturer = "Volkswagen", year = 1985),
        Car(id = 8, model = "Corcel", manufacturer = "Ford", year = 1975),
        Car(id = 9, model = "Chevette", manufacturer = "Chevrolet", year = 1982),
        Car(id = 10, model = "Puma GT", manufacturer = "Puma", year = 1978)
    )
}

fun getCarsByManufacturer(manufacturer: String): List<Car> {
    return getAllCars().filter {
        it.manufacturer.startsWith(prefix = manufacturer, ignoreCase = true)
    }
}