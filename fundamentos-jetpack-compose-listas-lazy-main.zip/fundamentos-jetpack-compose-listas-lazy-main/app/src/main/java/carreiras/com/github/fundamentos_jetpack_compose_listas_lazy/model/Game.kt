package carreiras.com.github.fundamentos_jetpack_compose_listas_lazy.model

data class Car(
    val id: Long = 0,
    val model: String = "",
    val manufacturer: String = "",
    val year: Int = 0
)